import {
  TYPESEARCH,
  CATEGORIES,
  CATEGORY,
  SEARCH,
  JOKES,
  FAVORITES,
} from "./types";

export function setTypeSearch(type) {
  return { type: TYPESEARCH, payload: type };
}

export function setCategories(category) {
  return { type: CATEGORIES, payload: category };
}
export function setCategory(category) {
  return { type: CATEGORY, payload: category };
}
export function setSearch(text) {
  return { type: SEARCH, payload: text };
}
export function setJokes(joke) {
  return { type: JOKES, payload: joke };
}
export function setFavoritesJokes(joke) {
  return { type: FAVORITES, payload: joke };
}

export function fetchCategoriesJoke() {
  return async (dispatch) => {
    const url = `https://api.chucknorris.io/jokes/categories`;
    const response = await fetch(url);
    const json = await response.json();
    dispatch(setCategories(json));
  };
}
export function fetchRandomJoke() {
  return async (dispatch) => {
    const url = `https://api.chucknorris.io/jokes/random`;
    const response = await fetch(url);
    const json = await response.json();
    dispatch(setJokes(json));
  };
}
export function fetchCategoryJoke() {
  return async (dispatch, getState) => {
    const category = getState().category;
    const url = `https://api.chucknorris.io/jokes/random?category=` + category;
    const response = await fetch(url);
    const json = await response.json();
    console.log(json);
    dispatch(setJokes(json));
  };
}
export function fetchSearchJoke() {
  return async (dispatch, getState) => {
    const search = getState().search;
    const url = `https://api.chucknorris.io/jokes/search?query=` + search;
    const response = await fetch(url);
    const json = await response.json();
    dispatch(setJokes(json));
  };
}
