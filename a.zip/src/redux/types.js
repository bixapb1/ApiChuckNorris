export const TYPESEARCH = "TYPESEARCH";
export const CATEGORIES = "CATEGORIES";
export const CATEGORY = "CATEGORY";
export const SEARCH = "SEARCH";
export const JOKES = "JOKES";
export const FAVORITES = "FAVORITES";
