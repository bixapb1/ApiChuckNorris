import { useDispatch, useSelector } from "react-redux";
import style from "../Content/style.module.css";
import Header from "./Header";
import TypeSearchBtn from "./Button/ButtonTypeSearch/index";
import Caterogies from "./Button/ButtonCategories/index";
import Search from "./Button/SearchInput";
import Card from "../Card";
import {
  fetchRandomJoke,
  fetchCategoryJoke,
  fetchSearchJoke,
} from "../../redux/action";

export default function Main() {
  const dispatch = useDispatch();
  const typeSearch = useSelector((state) => state.typeSearch);
  const jokes = useSelector((state) => state.jokes);
  function handlerBtnJoke() {
    if (typeSearch === "random") {
      dispatch(fetchRandomJoke());
    } else if (typeSearch === "caterogies") {
      dispatch(fetchCategoryJoke());
    } else if (typeSearch === "search") {
      dispatch(fetchSearchJoke());
    }
  }
  return (
    <>
      <div className={style.main}>
        <div className={style.container}>
          <Header />
          <TypeSearchBtn nameBtn={"random"} />
          <TypeSearchBtn nameBtn={"from caterogies"} value={"caterogies"} />
          {typeSearch === "caterogies" ? <Caterogies /> : ""}
          <TypeSearchBtn nameBtn={"search"} />
          {typeSearch === "search" ? <Search /> : ""}
          <button onClick={handlerBtnJoke} className={style.btn}>
            Get a joke
          </button>
          <Card jokes={jokes} style={style} />
        </div>
      </div>
    </>
  );
}
